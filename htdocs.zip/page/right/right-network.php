<?php 
include_once("name.php")

?>
	<?php 
include("db.php"); 
$fetchdata=new DB_con(); 
?>

<section class="section">

<div  class="right-div">

	<div id="main">
			<br>
	<div class="head">
		<div class="col-div-6">
		<p class="nav"><h1><?php echo $title3; ?></h1></p>
		</div>
		
	<div class="col-div-6">
		
		
		<div class="profile">
	
			<img src="" class="pro-img">
			<p><i class="" aria-hidden="false"></i></p>
			<div class="profile-div">
				<p><i class="fa fa-user"></i></p>
				<p><i class="fa fa-cogs"></i></p>
				<p><i class="fa fa-power-off"></i></p>
			</div>
		</div>
	</div>
		<div class="clearfix"></div>
	</div>
	
		<div class="clearfix"></div>
		<br><br><br>
		
		
		
		
		
		<div class="clearfix"></div>
		<br><br>
	
	
<div class="all" >

	<div class="users">
        <div class="card">
          <img src="../assets/ig/lec.png">
          <div class="per">
          </div>
          <button class="btn-send" onclick="show_pup()">Lectures</button>

		</div>
	</div>

	<div class="users">
        <div class="card">
          <img src="../assets/ig/section.png">          <div class="per">
          </div>
          <button onclick="show_pup2()">Sections</button>
        </div>

    </div>	<div class="users">
        <div class="card">
          <img src="../assets/ig/pdf.png">          <div class="per">
          </div>
          <button>PDF</button>
        </div>

    </div>    
 </div>

	<div class="clearfix"></div>
</div>
<div class="all-lec" id="pup">
		  <button class="btn-send" onclick="close_pup()">close</button>

		  <div class="container">

<div class="main-video-container active">
   <video src="images/vid-1.mp4" loop controls class="main-video" id="main1"></video>
   <h3 class="main-vid-title" id="maint1">اضغط علي الفيديو لبدء التشغيل</h3>
</div>

<div class="video-list-container" id="list1" >

	<div id="lecmath"></div>

	<?php 
$sql=$fetchdata->netlec(); 
$cnt=1; 
while($row=mysqli_fetch_array($sql)) 
{ 
?> 

   <div class="list" >
	  <video src="<?php echo $row['url']; ?>" class="list-video" ></video>
	  <h3 class="list-title" ><?php echo $row['name']; ?></h3>
   </div>

   <?php $cnt=$cnt+1;} ?> 


 </div>

</div>
</div>

<div class="all-lec" id="pup2">
		  <button class="btn-send" onclick="close_pup2()">close</button>

		  <div class="container">

<div class="main-video-container active" >

   <video src="images/vid-1.mp4" loop controls class="main-video"  id="main2" ></video>
   <h3 class="main-vid-title2" >اضغط علي الفيديو لبدء التشغيل</h3>
</div>
<div class="video-list-container" id="44" >

<?php 
$sql=$fetchdata->netsec(); 
$cnt=1; 
while($row=mysqli_fetch_array($sql)) 
{ 
?> 

   <div class="list" id='list'>
	  <video src="<?php echo $row['url']; ?>" class="list-video" id='list3'></video>
	  <h3 class="list-title" id='title3'><?php echo $row['name']; ?></h3>
   </div>

   <?php $cnt=$cnt+1;} ?> 

</div>

</div>









<script>
	function show_pup(){
		document.getElementById('pup2').classList.remove('open');
		document.getElementById('pup').classList.add('open');
	}
	function close_pup(){
		document.getElementById('pup').classList.remove('open');
		document.getElementById('pup2').classList.remove('open');

	}


</script>
<script>
 function show_pup2(){
	document.getElementById('pup').classList.remove('open');
	document.getElementById('pup2').classList.add('open');
	}
	function close_pup2(){
		document.getElementById('pup').classList.remove('open');
		document.getElementById('pup2').classList.remove('open');
	}
</script>

<!-- custom js file link  -->
<script src="../assets/css/i.js"></script>


