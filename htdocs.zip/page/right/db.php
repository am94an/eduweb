<?php 
session_start(); 
define('DB_SERVER','localhost'); 
define('DB_USER','root'); 
define('DB_PASS' ,''); 
define('DB_NAME', 'eelu'); 
class DB_con 
{ 
function __construct() 
{ 
$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME); 
$this->dbh=$con; 
// Check connection 
if (mysqli_connect_errno()) 
{ 
echo "Failed to connect to MySQL: " . mysqli_connect_error(); 
} 
} 
public function mathlec() 
{ 
$result=mysqli_query($this->dbh,"select * from `math` Where type='L'"); 

return $result; 
} 
public function mathsec() 
{ 
$result2=mysqli_query($this->dbh,"select * from `math` Where type='S'"); 

return $result2; 
} 
public function netlec() 
{ 
$result3=mysqli_query($this->dbh,"select * from `network` Where type='L'"); 

return $result3; 
} 
public function netsec() 
{ 
$result4=mysqli_query($this->dbh,"select * from `network` Where type='S'"); 

return $result4; 
} 
public function ooplec() 
{ 
$result5=mysqli_query($this->dbh,"select * from `oop` Where type='L'"); 

return $result5; 
} 
public function oopsec() 
{ 
$result6=mysqli_query($this->dbh,"select * from `oop` Where type='S'"); 

return $result6; 
} 
public function dblec() 
{ 
$result7=mysqli_query($this->dbh,"select * from `database` Where type='L'"); 

return $result7; 
} 
public function dbsec() 
{ 
$result8=mysqli_query($this->dbh,"select * from `database` Where type='S'"); 

return $result8; 
} 
public function probabilitylec() 
{ 
$result9=mysqli_query($this->dbh,"select * from `probability` Where type='L'"); 

return $result9; 
} 
public function probabilitysec() 
{ 
$result10=mysqli_query($this->dbh,"select * from `probability` Where type='S'"); 

return $result10; 
} 
public function softwarelec() 
{ 
$result11=mysqli_query($this->dbh,"select * from `software` Where type='L'"); 

return $result11; 
} 
public function softwaresec() 
{ 
$result12=mysqli_query($this->dbh,"select * from `software` Where type='S'"); 

return $result12; 
} 
} 
?> 
