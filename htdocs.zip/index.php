<?php 
$title="Home";
$page="Home";
include_once("page/head.php");
?>
<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        $(function(){
            $("#left").load("page/left.php");
        });
        $(function(){
            $("#home").load("page/home.php");
        });

        $(function(){
            $("#right").load("page/right.html");
        });
        $(function(){
            $("#left").load("page/right.html");
        });
    </script>
</head>
<body>

<section>
<div  class="left-div">		<br>
		<h2 class="logo">H -<span style="font-weight: 100; "> Darkcoder</span></h2>
		<hr class="hr" />
		<ul class="nav">
			<li class="active"><a onclick="show_div()"><i class="fa fa-th-large"></i> Home</a></li>
			<li class="list"><a href="math.php"><i class="fa fa-user"></i> math</a></li>
			<li class="list"><a href="oop.php?oop"><i class="fa fa-key"></i> oop</a></li>
			<li class="list"><a href="database.php?database"><i class="fa fa-desktop"></i> database</a></li>
			<li class="list"><a href="network.php?network"><i class="fa fa-gear"></i> network</a></li>
			<li class="list"><a href="software.php?software"><i class="fa fa-bullhorn"></i> software</a></li>
			<li class="list"><a href="Probability.php?Probability"><i class="fa fa-power-off"></i> Probability</a></li>
		</ul>
		<br><br>
		<a href="https://chat.whatsapp.com/KCFl9V5RGvFCPNJlZzRGfT"><img src="assets/ig/th.png" class="support"></a>
	</div>
	
    
	<div  class="right-div" >
        <div class="ho">    <?php 
    include_once('page/home.php') 
    ?>    </div>



		
    <div id="right" ></div>



</script>

</body>
</html>