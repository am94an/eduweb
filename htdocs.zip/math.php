<?php 
$title="Math";
$page="math";
include_once("page/head.php");
?>
<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        $(function(){
            $("#left").load("page/left.php");
        });

        $(function(){
            $("#right-math").load("page/right/right-math.php");
        });
        $(function(){
            $("#right").load("page/right.html");
        });
    </script>
	  <link href="https://vjs.zencdn.net/7.20.3/video-js.css" rel="stylesheet" />

<!-- If you'd like to support IE8 (for Video.js versions prior to v7) -->
<!-- <script src="https://vjs.zencdn.net/ie8/1.1.2/videojs-ie8.min.js"></script> -->

</head>
<body>

<section>
<div  class="left-div">		<br>
		<h2 class="logo">H -<span style="font-weight: 100; "> Darkcoder</span></h2>
		<hr class="hr" />
		<ul class="nav">
			<li class="list"><a href="index.php"><i class="fa fa-th-large"></i> Home</a></li>
			<li class="active"><a href="math.php"><i class="fa fa-user"></i> math</a></li>
			<li class="list"><a href="oop.php?oop"><i class="fa fa-key"></i> oop</a></li>
			<li class="list"><a href="database.php?database"><i class="fa fa-desktop"></i> database</a></li>
			<li class="list"><a href="network.php?network"><i class="fa fa-gear"></i> network</a></li>
			<li class="list"><a href="software.php?software"><i class="fa fa-bullhorn"></i> software</a></li>
			<li class="list"><a href="Probability.php?Probability"><i class="fa fa-power-off"></i> Probability</a></li>
		</ul>
		<br><br>
		<a href="https://chat.whatsapp.com/KCFl9V5RGvFCPNJlZzRGfT"><img src="assets/ig/th.png" class="support"></a>
</div>

<div id="right-math" ></div>



<div id="right" ></div>

</body>
</html>