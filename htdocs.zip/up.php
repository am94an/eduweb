<?php
// composer require transloadit/php-sdk
use transloadit\Transloadit;
$transloadit = new Transloadit([
  "key" => "68ea14b2eae1467e976ae2455cc661cc",
  "secret" => "f5dd255c17ed35730d8a8a7e4c4e1d344744cb87",
]);

// Add files to upload
$files = [];
array_push($files, "C:\Users\hossamaman\Desktop\New folder\section(1)Math-3.mp4")

// Start the Assembly
$response = $transloadit->createAssembly([
  "files" => $files, 
  "params" => [
    "template_id" => "6358f6c054b54f9a91fc9fb62c186215",
  ]
]);
?>