let videoList = document.querySelectorAll('.video-list-container .list');

videoList.forEach(vid =>{
   vid.onclick = () =>{
      videoList.forEach(remove =>{remove.classList.remove('active')});
      vid.classList.add('active');
      let src = vid.querySelector('.list-video').src;
      let title = vid.querySelector('.list-title').innerHTML;
      document.querySelector('.main-video-container .main-video').src = src;
      document.querySelector('.main-video-container .main-video').play();
      document.querySelector('.main-video-container .main-vid-title').innerHTML = title;
   };
});
let videoList2 = document.querySelectorAll('.video-list-container2 .list');

videoList2.forEach(vid =>{
   vid.onclick = () =>{
      videoList2.forEach(remove =>{remove.classList.remove('active')});
      vid.classList.add('active');
      let src = vid.querySelector('[id*="list3"]').src;
      let title = vid.querySelector('[id*="title3"]').innerHTML;
      document.querySelector('[id*="main2"]').src = src;
      document.querySelector('[id*="main2"]').play();
      document.querySelector('[id*="title21"]').innerHTML = title;
   };
});
