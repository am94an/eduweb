-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 13, 2022 at 01:16 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eelu`
--

-- --------------------------------------------------------

--
-- Table structure for table `database`
--

CREATE TABLE `database` (
  `id` int(1) NOT NULL,
  `name` text NOT NULL,
  `url` text NOT NULL,
  `type` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `database`
--

INSERT INTO `database` (`id`, `name`, `url`, `type`) VALUES
(5, '1', 'https://cdn.filestackcontent.com/J8xMPqDCQHqCOfGEY2GL', 'L'),
(6, 'المحاضره الاولي', 'https://cdn.filestackcontent.com/J8xMPqDCQHqCOfGEY2GL', 'L');

-- --------------------------------------------------------

--
-- Table structure for table `math`
--

CREATE TABLE `math` (
  `id` int(1) NOT NULL,
  `name` text NOT NULL,
  `url` text NOT NULL,
  `type` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `math`
--

INSERT INTO `math` (`id`, `name`, `url`, `type`) VALUES
(1, 'المحاضره الاولي', 'a\\Mathematics (3)_Lec01_11Oct_2022.mp4', 'L'),
(3, '2', 'https://cdn.filestackcontent.com/t15RDcx6RG4vowp1yyLW', 'S'),
(4, '2', 'https://studenteeluedu-my.sharepoint.com/personal/ahmed21-01834_student_eelu_edu_eg/_layouts/15/download.aspx?SourceUrl=%2Fpersonal%2Fahmed21%2D01834%5Fstudent%5Feelu%5Fedu%5Feg%2FDocuments%2Fsemester%203%2Fdatabase%2FIntroduction%20to%20Database%20Systems%5FLec01%5F11Oct%5F2022%2Emp4&correlationid=844d40d5-2673-46c9-ae0a-9b79822d3607&client=streamvideoplayer', 'S'),
(7, '2المحاضره ', 'https://cdn.filestackcontent.com/J8xMPqDCQHqCOfGEY2GL', 'L');

-- --------------------------------------------------------

--
-- Table structure for table `network`
--

CREATE TABLE `network` (
  `id` int(1) NOT NULL,
  `name` text NOT NULL,
  `url` text NOT NULL,
  `type` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `network`
--

INSERT INTO `network` (`id`, `name`, `url`, `type`) VALUES
(1, '1', 'https://res.cloudinary.com/drfplw8yy/video/upload/v1667968353/math/network_section_3_j6mdvk.mp4', 'S');

-- --------------------------------------------------------

--
-- Table structure for table `oop`
--

CREATE TABLE `oop` (
  `id` int(1) NOT NULL,
  `name` text NOT NULL,
  `url` text NOT NULL,
  `type` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oop`
--

INSERT INTO `oop` (`id`, `name`, `url`, `type`) VALUES
(5, '1', 'https://res.cloudinary.com/drfplw8yy/video/upload/v1667969078/math/opp_sec_1_ue1atx.mp4', 'S'),
(7, '2', 'https://res.cloudinary.com/drfplw8yy/video/upload/v1667969532/math/OPP_sec_2_lng1v2.mp4', 'S');

-- --------------------------------------------------------

--
-- Table structure for table `probability`
--

CREATE TABLE `probability` (
  `id` int(1) NOT NULL,
  `name` text NOT NULL,
  `url` text NOT NULL,
  `type` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `software`
--

CREATE TABLE `software` (
  `id` int(1) NOT NULL,
  `name` text NOT NULL,
  `url` text NOT NULL,
  `type` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `database`
--
ALTER TABLE `database`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `math`
--
ALTER TABLE `math`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `network`
--
ALTER TABLE `network`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oop`
--
ALTER TABLE `oop`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `probability`
--
ALTER TABLE `probability`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `software`
--
ALTER TABLE `software`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `database`
--
ALTER TABLE `database`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `math`
--
ALTER TABLE `math`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `network`
--
ALTER TABLE `network`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `oop`
--
ALTER TABLE `oop`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `probability`
--
ALTER TABLE `probability`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `software`
--
ALTER TABLE `software`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
